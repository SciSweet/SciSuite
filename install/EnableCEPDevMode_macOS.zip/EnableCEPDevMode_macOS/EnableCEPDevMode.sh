#!/bin/bash
# EnableCEPDevMode.sh
# Enables Adobe CEP developer mode for self-signed extensions (SciSuite).
# Run in Terminal:  chmod +x EnableCEPDevMode.sh && ./EnableCEPDevMode.sh

defaults write com.adobe.CSXS.9  PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1

echo "CEP developer mode enabled (CSXS 9–12)."
echo "Please restart Photoshop / Illustrator if they are running."
