#!/bin/bash
# DisableCEPDevMode.sh
# Disables Adobe CEP developer mode.
# Run in Terminal:  chmod +x DisableCEPDevMode.sh && ./DisableCEPDevMode.sh

defaults delete com.adobe.CSXS.9  PlayerDebugMode 2>/dev/null
defaults delete com.adobe.CSXS.10 PlayerDebugMode 2>/dev/null
defaults delete com.adobe.CSXS.11 PlayerDebugMode 2>/dev/null
defaults delete com.adobe.CSXS.12 PlayerDebugMode 2>/dev/null

echo "CEP developer mode disabled (CSXS 9–12)."
echo "Please restart Photoshop / Illustrator if they are running."
